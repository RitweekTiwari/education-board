<script type="text/javascript">
$(document).ready(function(){
  var c =   $("#choice").val();
  $("#userid").attr("type",p1);

  $('#choice').change(function(){
  var c =   $("#choice").val();
  $("#userid").attr("type",p1);
});

});
</script>