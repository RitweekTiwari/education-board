<!-- Multi Upload Start-->
<div class="multi-uploaded-area mg-b-15">
    <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="dropzone-pro">
                    <div class="multi-uploader-cs">
                        <form  id="file_upload"  class="dropzone dropzone-custom needsclick" enctype="multipart/form-data">
                            <div class="dz-message needsclick download-custom">
                                <i class="fa fa-cloud-download" aria-hidden="true"></i>
                                <h2>Drop files here or click to upload.</h2>
                                <button type="button" class="btn btn-primary" name="button">select File</button>
                                <p><span class="note needsclick">( only <strong>[jpg, png, jpeg, gif]</strong> file are allows to uploaded.)</span>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Multi Upload End-->
