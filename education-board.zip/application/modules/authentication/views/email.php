<!DOCTYPE html> 


<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<head>


<style type="text/css">
.ReadMsgBody {width: 100%;}
.ExternalClass {width: 100%;}
.mobile {display: none;overflow: hidden;visibility:hidden;}
strong{font-weight: bold;}

	@media only screen and (max-width: 479px){ /**change to max-device-width after testing**/
		
	     td[class="desktop"], table[class="desktop"] {
	         display: none !important;
	     }
     	
		 td[class="mobile_only"], table[class="mobile_only"], img[class="mobile_only"], div[class="mobile_only"], tr[class="mobile_only"] {
			display: block !important;
 			width: auto !important;
  			overflow: visible !important;
			height: auto !important;
			max-height: inherit !important;
			font-size: 15px !important;
			line-height: 21px !important;
			visibility: visible !important;
	     }		 
		 
		 img[class="mobile_header"] { 
		 	width: 320px !important;
			height: 243px !important;
			display: block !important; 			
  			overflow: visible !important;
			visibility: visible !important;}
		 
		 td[class="full_width"], table[class="full_width"] {
	          width: 320px !important;
	     }
	    
		 td[class="medium_width"], table[class="medium_width"] {
	          width: 272px !important;
	     }
		 	 
		 td[class="intro_text"], table[class="intro_text"] {
	     	font-size: 14px !important;
			line-height: 20px !important;
	     }
		
	}
	tr td p{
	    padding-left:20px;
	}
</style>

</head>

<body bgcolor="#f5f5f5" style="background-color:#f5f5f5; margin:0; padding:0;-webkit-font-smoothing: antialiased;width:100% !important;-webkit-text-size-adjust:none;" topmargin="0">

<table align="center" width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr>  
       <td height="12" bgcolor="#f5f5f5" style="font-size: 0px; line-height: 0px;">&nbsp;</td>
    </tr>
</table>


<!-- wrapper table-->
<table width="100%" bgcolor="#f5f5f5" style="background-color:#f5f5f5;" border="0" cellpadding="0" cellspacing="0">
  <tr>
	<td>&nbsp;</td>

    <td class="full_width" width="650" align="center" style="border-left:1px solid #d8d8d8; border-right:1px solid #d8d8d8; border-bottom:1px solid #d8d8d8; border-top:1px solid #d8d8d8;background-color: #ffffff; padding-bottom: 30px;">
      
      <!-- header image -->
      
    <!--spacer-->
    
     <table align="center" width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>  
           <td height="24" style="font-size: 0px; line-height: 0px;">&nbsp;</td>
        </tr>
     </table>
    
    <!-- headline-->

    <table class="full_width" align="center" width="100%" border="0" cellpadding="0" cellspacing="0" style="border-bottom:1px solid #d9d9d9;" >
        <tr> 
           
           <td width="100%"><img alt="Logo" src="<?php echo base_url('optimum/img/educationaduca.png')?>" width="350" height="170" border="0"  tyle="display:block; vertical-align:top;"></td>
           
        </tr>
       
      </table>  
    
     <table align="center" width="100%">      
      
           
          
       
       <tr> <td ><p>Email Id :- <?php echo $email ?></p></td></tr>
       <tr><td><p>Password :- <?php echo $password ?></p></td> </tr>
       
        
      
       
       
     </table>
      
      
       
    <!-- headline-->    
    
      
      <table class="medium_width" align="center" width="100%">
        <tr>      
          <td class="desktop" width="67" style="padding-top:12px;">&nbsp;</td> 
          <td align="right" valign="top" style="border-top:1px solid #d9d9d9; padding-top:12px;">
          		<table width="100%">
                 <tr style="text-align: center;">
                   
                    
                 </tr>
              </table>
          </td>
          <td class="desktop" width="67" style="padding-top:12px;">&nbsp;</td>             
        </tr>
      </table>
      
    </td>
    <td>&nbsp;</td>
  </tr>
</table> <!--/end wrapper-->

</body>
</html>